package softuni.exam.instagraphlite.config;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;


//ToDo
public class ApplicationBeanConfiguration {

}
