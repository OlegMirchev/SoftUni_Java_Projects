package softuni.exam.util;

public enum CarType {
    SUV, coupe, sport
}
